﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Taylor.Travis.Business;

namespace LibraryTest
{
    [TestClass]
    public class CarWashInvoiceTest
    {
        [TestMethod]
        public void Constructor_4Param_Valid_Test()
        {
            decimal provincialSalesTaxRate = 0.07m;
            decimal goodsAndServicesTaxRate = 0.06m;
            decimal packageCost = 20.00m;
            decimal fragranceCost = 5.00m;
            CarWashInvoice test = new CarWashInvoice(provincialSalesTaxRate, goodsAndServicesTaxRate, packageCost, fragranceCost);

            decimal expectedPST = 0.07m;
            decimal expectedGST = 0.06m;
            decimal expectedPackageCost = 20.00m;
            decimal expectedFragranceCost = 5.00m;

            PrivateObject testDerived = new PrivateObject(test);
            PrivateObject testBase = new PrivateObject(test, new PrivateType(typeof(Invoice)));
            decimal actualPST = (decimal)testBase.GetField("provincialSalesTaxRate");
            decimal actualGST = (decimal)testBase.GetField("goodsAndServicesTaxRate");
            decimal actualPackage = (decimal)testDerived.GetField("packageCost");
            decimal actualFragrance = (decimal)testDerived.GetField("fragranceCost");

            Assert.AreEqual(expectedPST, actualPST);
            Assert.AreEqual(expectedGST, actualGST);
            Assert.AreEqual(expectedPackageCost, actualPackage);
            Assert.AreEqual(expectedFragranceCost, actualFragrance);
        }

        [TestMethod]
        public void Constructor_2Param_Valid_Test()
        {
            decimal provincialSalesTaxRate = 0.08m;
            decimal goodsAndServicesTaxRate = 0.05m;
            CarWashInvoice test = new CarWashInvoice(provincialSalesTaxRate, goodsAndServicesTaxRate);

            decimal expectedPST = 0.08m;
            decimal expectedGST = 0.05m;
            PrivateObject target = new PrivateObject(test, new PrivateType(typeof(Invoice)));
            decimal actualPST = (decimal)target.GetField("provincialSalesTaxRate");
            decimal actualGST = (decimal)target.GetField("goodsAndServicesTaxRate");
            Assert.AreEqual(expectedPST, actualPST);
            Assert.AreEqual(expectedGST, actualGST);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void Constructor_PSTCannotBeLessThanZero_Test()
        {
            decimal provincialSalesTaxRate = -0.10m;
            decimal goodsAndServicesTaxRate = 0.04m;
            CarWashInvoice test = new CarWashInvoice(provincialSalesTaxRate, goodsAndServicesTaxRate);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void Constructor_PSTCannotBeGreaterThanOne_Test()
        {
            decimal provincialSalesTaxRate = 10m;
            decimal goodsAndServicesTaxRate = 0.03m;
            CarWashInvoice test = new CarWashInvoice(provincialSalesTaxRate, goodsAndServicesTaxRate);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void Constructor_GSTCannotBeLessThanZero_Test()
        {
            decimal provincialSalesTaxRate = 0.10m;
            decimal goodsAndServicesTaxRate = -0.04m;
            CarWashInvoice test = new CarWashInvoice(provincialSalesTaxRate, goodsAndServicesTaxRate);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void Constructor_GSTCannotBeGreaterThanOne_Test()
        {
            decimal provincialSalesTaxRate = 0.08m;
            decimal goodsAndServicesTaxRate = 4m;
            CarWashInvoice test = new CarWashInvoice(provincialSalesTaxRate, goodsAndServicesTaxRate);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void Constructor_PackageCostCannotBeLessThanZero_Test()
        {
            decimal provincialSalesTaxRate = 0.10m;
            decimal goodsAndServicesTaxRate = 0.02m;
            decimal packageCost = -8m;
            decimal fragranceCost = 3.99m;
            CarWashInvoice test = new CarWashInvoice(provincialSalesTaxRate, goodsAndServicesTaxRate, packageCost, fragranceCost);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void Constructor_FragranceCostCannotBeLessThanZero_Test()
        {
            decimal provincialSalesTaxRate = 0.10m;
            decimal goodsAndServicesTaxRate = 0.02m;
            decimal packageCost = 19.99m;
            decimal fragranceCost = -399m;
            CarWashInvoice test = new CarWashInvoice(provincialSalesTaxRate, goodsAndServicesTaxRate, packageCost, fragranceCost);
        }

        //PackageCost property
        [TestMethod]
        public void PackageCostProperty_GetAccessor_Test()
        {
            decimal provincialSalesTaxRate = 0.10m;
            decimal goodsAndServicesTaxRate = 0.04m;
            decimal packageCost = 18.96m;
            decimal fragranceCost = 5.66m;
            CarWashInvoice test = new CarWashInvoice(provincialSalesTaxRate, goodsAndServicesTaxRate, packageCost, fragranceCost);

            decimal expectedPackageCost = 18.96m;
            decimal actualPackageCost = test.PackageCost;
            Assert.AreEqual(expectedPackageCost, actualPackageCost);
        }

        [TestMethod]
        public void PackageCostProperty_SetAccessor_Test()
        {
            decimal provincialSalesTaxRate = 0.10m;
            decimal goodsAndServicesTaxRate = 0.04m;
            decimal packageCost = 18.96m;
            decimal fragranceCost = 5.66m;
            CarWashInvoice test = new CarWashInvoice(provincialSalesTaxRate, goodsAndServicesTaxRate, packageCost, fragranceCost);

            test.PackageCost = 23.99m;
            decimal expectedPackageCost = 23.99m;
            PrivateObject target = new PrivateObject(test);
            decimal actualPackageCost = (decimal)target.GetField("packageCost");
            Assert.AreEqual(expectedPackageCost, actualPackageCost);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void PackageCost_ValueCannotBeLessThanZero_Test()
        {
            decimal provincialSalesTaxRate = 0.10m;
            decimal goodsAndServicesTaxRate = 0.04m;
            decimal packageCost = -10m;
            decimal fragranceCost = 4.66m;
            CarWashInvoice test = new CarWashInvoice(provincialSalesTaxRate, goodsAndServicesTaxRate, packageCost, fragranceCost);
        }

        [TestMethod]
        public void PackageCostProperty_StateNotUpdatedOnException_ValueLessThanZero_Test()
        {
            decimal provincialSalesTaxRate = 0.10m;
            decimal goodsAndServicesTaxRate = 0.04m;
            decimal packageCost = 18.96m;
            decimal fragranceCost = 5.66m;
            CarWashInvoice test = new CarWashInvoice(provincialSalesTaxRate, goodsAndServicesTaxRate, packageCost, fragranceCost);
            decimal expectedPackageCost = 18.96m;

            try
            {
                test.PackageCost = -4m;
                Assert.Fail("Did not throw ArgumentOutOfRangeException as expected.");
            }
            catch (ArgumentOutOfRangeException)
            {
                PrivateObject target = new PrivateObject(test);
                decimal actualPackageCost = (decimal)target.GetField("packageCost");
                Assert.AreEqual(expectedPackageCost, actualPackageCost);
            }
        }

        //FragranceCost property
        [TestMethod]
        public void FragranceCostProperty_GetAccessor_Test()
        {
            decimal provincialSalesTaxRate = 0.10m;
            decimal goodsAndServicesTaxRate = 0.04m;
            decimal packageCost = 18.96m;
            decimal fragranceCost = 3.45m;
            CarWashInvoice test = new CarWashInvoice(provincialSalesTaxRate, goodsAndServicesTaxRate, packageCost, fragranceCost);

            decimal expectedFragranceCost = 3.45m;
            decimal actualFragranceCost = test.FragranceCost;
            Assert.AreEqual(expectedFragranceCost, actualFragranceCost);
        }

        [TestMethod]
        public void FragranceCostProperty_SetAccessor_Test()
        {
            decimal provincialSalesTaxRate = 0.10m;
            decimal goodsAndServicesTaxRate = 0.04m;
            decimal packageCost = 18.96m;
            decimal fragranceCost = 5.66m;
            CarWashInvoice test = new CarWashInvoice(provincialSalesTaxRate, goodsAndServicesTaxRate, packageCost, fragranceCost);
            test.FragranceCost = 18.99m;

            decimal expectedFragranceCost = 18.99m;
            PrivateObject target = new PrivateObject(test);
            decimal actualFragranceCost = (decimal)target.GetField("fragranceCost");
            Assert.AreEqual(expectedFragranceCost, actualFragranceCost);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void FragranceCostProperty_ValueCannotBeLessThanZero_Test()
        {
            decimal provincialSalesTaxRate = 0.10m;
            decimal goodsAndServicesTaxRate = 0.04m;
            decimal packageCost = 18.96m;
            decimal fragranceCost = 5.66m;
            CarWashInvoice test = new CarWashInvoice(provincialSalesTaxRate, goodsAndServicesTaxRate, packageCost, fragranceCost);
            test.FragranceCost = -4.55m;
        }

        [TestMethod]
        public void FragranceCostProperty_StateNotUpdatedOnException_Test()
        {
            decimal provincialSalesTaxRate = 0.10m;
            decimal goodsAndServicesTaxRate = 0.04m;
            decimal packageCost = 18.96m;
            decimal fragranceCost = 5.66m;
            CarWashInvoice test = new CarWashInvoice(provincialSalesTaxRate, goodsAndServicesTaxRate, packageCost, fragranceCost);
            decimal expectedFragranceCost = 5.66m;

            try
            {
                test.FragranceCost = -89m;
                Assert.Fail("Did not throw ArgumentOutOfRangeException as expected.");
            }
            catch(ArgumentOutOfRangeException)
            {
                PrivateObject target = new PrivateObject(test);
                decimal actualFragranceCost = (decimal)target.GetField("fragranceCost");
                Assert.AreEqual(expectedFragranceCost, actualFragranceCost);
            }
        }

        //ProvincialSalesTaxRate property
        [TestMethod]
        public void ProvincialSalesTaxRateProperty_GetAccessor_Test()
        {
            decimal provincialSalesTaxRate = 0.08m;
            decimal goodsAndServicesTaxRate = 0.07m;
            ServiceInvoice test = new ServiceInvoice(provincialSalesTaxRate, goodsAndServicesTaxRate);

            decimal expectedPST = 0.08m;
            decimal actualPST = test.ProvincialSalesTaxRate;
            Assert.AreEqual(expectedPST, actualPST);
        }

        [TestMethod]
        public void ProvincialSalesTaxRateProperty_SetAccessor_Test()
        {
            decimal provincialSalesTaxRate = 0.09m;
            decimal goodsAndServicesTaxRate = 0.05m;
            ServiceInvoice test = new ServiceInvoice(provincialSalesTaxRate, goodsAndServicesTaxRate);
            test.ProvincialSalesTaxRate = 0.12m;

            decimal expectedPST = 0.12m;
            PrivateObject target = new PrivateObject(test, new PrivateType(typeof(Invoice)));
            decimal actualPST = (decimal)target.GetField("provincialSalesTaxRate");
            Assert.AreEqual(expectedPST, actualPST);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void ProvincialSalesTaxRateProperty_ValueCannotBeLessThanZero_Test()
        {
            decimal provincialSalesTaxRate = 0.04m;
            decimal goodsAndServicesTaxRate = 0.2m;
            ServiceInvoice test = new ServiceInvoice(provincialSalesTaxRate, goodsAndServicesTaxRate);
            test.ProvincialSalesTaxRate = -99m;
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void ProvincialSalesTaxRateProperty_ValueCannotBeGreaterThanOne_Test()
        {
            decimal provincialSalesTaxRate = 0.04m;
            decimal goodsAndServicesTaxRate = 0.2m;
            ServiceInvoice test = new ServiceInvoice(provincialSalesTaxRate, goodsAndServicesTaxRate);
            test.ProvincialSalesTaxRate = 99m;
        }

        [TestMethod]
        public void ProvincialSalesTaxRateProperty_StateNotUpdatedOnException_ValueLessThanZero_Test()
        {
            decimal provincialSalesTaxRate = 0.04m;
            decimal goodsAndServicesTaxRate = 0.2m;
            ServiceInvoice test = new ServiceInvoice(provincialSalesTaxRate, goodsAndServicesTaxRate);
            decimal expectedPST = 0.04m;

            try
            {
                test.ProvincialSalesTaxRate = -9m;
                Assert.Fail("Did not throw ArgumentOutOfRangeException as expected.");
            }
            catch (ArgumentOutOfRangeException)
            {
                PrivateObject target = new PrivateObject(test, new PrivateType(typeof(Invoice)));
                decimal actualPST = (decimal)target.GetField("provincialSalesTaxRate");
                Assert.AreEqual(expectedPST, actualPST);
            }
        }

        [TestMethod]
        public void ProvincialSalesTaxRateProperty_StateNotUpdatedOnException_ValueGreaterThanOne_Test()
        {
            decimal provincialSalesTaxRate = 0.07m;
            decimal goodsAndServicesTaxRate = 0.2m;
            ServiceInvoice test = new ServiceInvoice(provincialSalesTaxRate, goodsAndServicesTaxRate);
            decimal expectedPST = 0.07m;

            try
            {
                test.ProvincialSalesTaxRate = 9m;
                Assert.Fail("Did not throw ArgumentOutOfRangeException as expected.");
            }
            catch (ArgumentOutOfRangeException)
            {
                PrivateObject target = new PrivateObject(test, new PrivateType(typeof(Invoice)));
                decimal actualPST = (decimal)target.GetField("provincialSalesTaxRate");
                Assert.AreEqual(expectedPST, actualPST);
            }
        }

        //GoodsAndServicesTaxRate property
        [TestMethod]
        public void GoodsAndServicesTaxRateProperty_GetAccessor_Test()
        {
            decimal provincialSalesTaxRate = 0.07m;
            decimal goodsAndServicesTaxRate = 0.02m;
            CarWashInvoice test = new CarWashInvoice(provincialSalesTaxRate, goodsAndServicesTaxRate);

            decimal expectedGST = 0.02m;
            decimal actualGST = test.GoodsAndServicesTaxRate;
            Assert.AreEqual(expectedGST, actualGST);
        }

        [TestMethod]
        public void GoodsAndServicesTaxRateProperty_SetAccessor_Test()
        {
            decimal provincialSalesTaxRate = 0.07m;
            decimal goodsAndServicesTaxRate = 0.2m;
            CarWashInvoice test = new CarWashInvoice(provincialSalesTaxRate, goodsAndServicesTaxRate);
            decimal expectedGST = 0.45m;
            test.GoodsAndServicesTaxRate = 0.45m;

            PrivateObject target = new PrivateObject(test, new PrivateType(typeof(Invoice)));
            decimal actualGST = (decimal)target.GetField("goodsAndServicesTaxRate");
            Assert.AreEqual(expectedGST, actualGST);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void GoodAndServicesTaxRateProperty_ValueCannotBeLessThanZero_Test()
        {
            decimal provincialSalesTaxRate = 0.07m;
            decimal goodsAndServicesTaxRate = 0.2m;
            CarWashInvoice test = new CarWashInvoice(provincialSalesTaxRate, goodsAndServicesTaxRate);
            test.GoodsAndServicesTaxRate = -9m;
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void GoodsAndServicesTaxRateProperty_ValueCannotBeGreaterThanOne_Test()
        {
            decimal provincialSalesTaxRate = 0.07m;
            decimal goodsAndServicesTaxRate = 0.2m;
            CarWashInvoice test = new CarWashInvoice(provincialSalesTaxRate, goodsAndServicesTaxRate);
            test.GoodsAndServicesTaxRate = 9m;
        }

        [TestMethod]
        public void GoodsAndServicesTaxRateProperty_StateNotUpdatedOnException_ValueLessThanZero_Test()
        {
            decimal provincialSalesTaxRate = 0.07m;
            decimal goodsAndServicesTaxRate = 0.01m;
            CarWashInvoice test = new CarWashInvoice(provincialSalesTaxRate, goodsAndServicesTaxRate);
            decimal expectedGST = 0.01m;

            try
            {
                test.GoodsAndServicesTaxRate = -8m;
                Assert.Fail("Did not throw ArgumentOutOfRangeException as expected.");
            }
            catch (ArgumentOutOfRangeException)
            {
                PrivateObject target = new PrivateObject(test, new PrivateType(typeof(Invoice)));
                decimal actualGST = (decimal)target.GetField("goodsAndServicesTaxRate");
                Assert.AreEqual(expectedGST, actualGST);
            }
        }

        [TestMethod]
        public void GoodsAndServicesTaxRateProperty_StateNotUpdatedOnException_ValueGreaterThanOne_Test()
        {
            decimal provincialSalesTaxRate = 0.07m;
            decimal goodsAndServicesTaxRate = 0.04m;
            CarWashInvoice test = new CarWashInvoice(provincialSalesTaxRate, goodsAndServicesTaxRate);
            decimal expectedGST = 0.04m;

            try
            {
                test.GoodsAndServicesTaxRate = 8m;
                Assert.Fail("Did not throw ArgumentOutOfRangeException as expected.");
            }
            catch (ArgumentOutOfRangeException)
            {
                PrivateObject target = new PrivateObject(test, new PrivateType(typeof(Invoice)));
                decimal actualGST = (decimal)target.GetField("goodsAndServicesTaxRate");
                Assert.AreEqual(expectedGST, actualGST);
            }
        }

        //ProvincialSalesTaxCharged property
        [TestMethod]
        public void ProvincialSalesTaxChargedProperty_Test()
        {
            decimal provincialSalesTaxRate = 0.10m;
            decimal goodsAndServicesTaxRate = 0.02m;
            decimal packageCost = 19.99m;
            decimal fragranceCost = 3.99m;
            CarWashInvoice test = new CarWashInvoice(provincialSalesTaxRate, goodsAndServicesTaxRate, packageCost, fragranceCost);

            decimal expectedPSTCharged = 0m; //0 PST is charged on car wash
            decimal actualPSTCharged = test.ProvincialSalesTaxCharged;
            Assert.AreEqual(expectedPSTCharged, actualPSTCharged);
        }

        //GoodsAndServicesSalesTaxCharged property
        [TestMethod]
        public void GoodsAndServicesTaxChargedProperty_Test()
        {
            decimal provincialSalesTaxRate = 0.10m;
            decimal goodsAndServicesTaxRate = 0.02m;
            decimal packageCost = 19.99m;
            decimal fragranceCost = 3.99m;
            CarWashInvoice test = new CarWashInvoice(provincialSalesTaxRate, goodsAndServicesTaxRate, packageCost, fragranceCost);

            decimal expectedGSTCharged = 0.4796m;
            decimal actualGSTCharged = test.GoodsAndServicesTaxCharged;
            Assert.AreEqual(expectedGSTCharged, actualGSTCharged);
        }

        //SubTotal property
        [TestMethod]
        public void SubTotalProperty_Test()
        {
            decimal provincialSalesTaxRate = 0.10m;
            decimal goodsAndServicesTaxRate = 0.02m;
            decimal packageCost = 19.99m;
            decimal fragranceCost = 3.99m;
            CarWashInvoice test = new CarWashInvoice(provincialSalesTaxRate, goodsAndServicesTaxRate, packageCost, fragranceCost);

            decimal expectedSubtotal = 23.98m;
            decimal actualSubtotal = test.SubTotal;
            Assert.AreEqual(expectedSubtotal, actualSubtotal);
        }

        //Total property
        [TestMethod]
        public void TotalProperty_Test()
        {
            decimal provincialSalesTaxRate = 0.10m;
            decimal goodsAndServicesTaxRate = 0.02m;
            decimal packageCost = 19.99m;
            decimal fragranceCost = 3.99m;
            CarWashInvoice test = new CarWashInvoice(provincialSalesTaxRate, goodsAndServicesTaxRate, packageCost, fragranceCost);

            decimal expectedTotal = 24.4596m;
            decimal actualTotal = test.Total;
            Assert.AreEqual(expectedTotal, actualTotal);
        }
    }
}
