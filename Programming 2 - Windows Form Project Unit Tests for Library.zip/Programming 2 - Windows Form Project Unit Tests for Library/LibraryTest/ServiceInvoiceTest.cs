﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Taylor.Travis.Business;

namespace LibraryTest
{
    [TestClass]
    public class ServiceInvoiceTest
    {
        [TestMethod]
        public void Constructor_Valid_Test()
        {
            //Arrange
            decimal provincialSalesTaxRateTest = 0.07m;
            decimal goodsAndServicesTaxRateTest = 0.06m;
            ServiceInvoice test = new ServiceInvoice(provincialSalesTaxRateTest, goodsAndServicesTaxRateTest);

            //Act - Must create 2 private objects, one for dervied and one for base - Access though base.
            decimal expectedPST = 0.07m;
            decimal expectedGST = 0.06m;
            PrivateObject targetDerived = new PrivateObject(test);
            PrivateObject targetBase = new PrivateObject(test, new PrivateType(typeof(Invoice)));
            decimal actualPST = (decimal)targetBase.GetField("provincialSalesTaxRate");
            decimal actualGST = (decimal)targetBase.GetField("goodsAndServicesTaxRate");

            //Assert
            Assert.AreEqual(expectedPST, actualPST);
            Assert.AreEqual(expectedGST, actualGST);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void Constructor_PST_CannotBeLessThanZero_Test()
        {
            decimal provincialSalesTaxRate = -0.06m;
            decimal goodsAndServicesTaxRate = 0.05m;
            ServiceInvoice test = new ServiceInvoice(provincialSalesTaxRate, goodsAndServicesTaxRate);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void Constructor_PST_CannotBeGreaterThanOne_Test()
        {
            decimal provincialSalesTaxRate = 1.06m;
            decimal goodsAndServicesTaxRate = 0.05m;
            ServiceInvoice test = new ServiceInvoice(provincialSalesTaxRate, goodsAndServicesTaxRate);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void Constructor_GST_CannotBeLessThanZero_Test()
        {
            decimal provincialSalesTaxRate = 0.06m;
            decimal goodsAndServicesTaxRate = -0.05m;
            ServiceInvoice test = new ServiceInvoice(provincialSalesTaxRate, goodsAndServicesTaxRate);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void Constructor_GST_CannotBeGreaterThanOne_Test()
        {
            decimal provincialSalesTaxRate = 0.06m;
            decimal goodsAndServicesTaxRate = 1.05m;
            ServiceInvoice test = new ServiceInvoice(provincialSalesTaxRate, goodsAndServicesTaxRate);
        }

        //ProvincialSalesTaxRate property
        [TestMethod]
        public void ProvincialSalesTaxRateProperty_GetAccessor_Test()
        {
            decimal provincialSalesTaxRate = 0.08m;
            decimal goodsAndServicesTaxRate = 0.07m;
            ServiceInvoice test = new ServiceInvoice(provincialSalesTaxRate, goodsAndServicesTaxRate);

            decimal expectedPST = 0.08m;
            decimal actualPST = test.ProvincialSalesTaxRate;
            Assert.AreEqual(expectedPST, actualPST);
        }

        [TestMethod]
        public void ProvincialSalesTaxRateProperty_SetAccessor_Test()
        {
            decimal provincialSalesTaxRate = 0.09m;
            decimal goodsAndServicesTaxRate = 0.05m;
            ServiceInvoice test = new ServiceInvoice(provincialSalesTaxRate, goodsAndServicesTaxRate);
            test.ProvincialSalesTaxRate = 0.12m;

            decimal expectedPST = 0.12m;
            PrivateObject target = new PrivateObject(test, new PrivateType(typeof(Invoice)));
            decimal actualPST = (decimal)target.GetField("provincialSalesTaxRate");
            Assert.AreEqual(expectedPST, actualPST);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void ProvincialSalesTaxRateProperty_ValueCannotBeLessThanZero_Test()
        {
            decimal provincialSalesTaxRate = 0.04m;
            decimal goodsAndServicesTaxRate = 0.2m;
            ServiceInvoice test = new ServiceInvoice(provincialSalesTaxRate, goodsAndServicesTaxRate);
            test.ProvincialSalesTaxRate = -99m;
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void ProvincialSalesTaxRateProperty_ValueCannotBeGreaterThanOne_Test()
        {
            decimal provincialSalesTaxRate = 0.04m;
            decimal goodsAndServicesTaxRate = 0.2m;
            ServiceInvoice test = new ServiceInvoice(provincialSalesTaxRate, goodsAndServicesTaxRate);
            test.ProvincialSalesTaxRate = 99m;
        }

        [TestMethod]
        public void ProvincialSalesTaxRateProperty_StateNotUpdatedOnException_ValueLessThanZero_Test()
        {
            decimal provincialSalesTaxRate = 0.04m;
            decimal goodsAndServicesTaxRate = 0.2m;
            ServiceInvoice test = new ServiceInvoice(provincialSalesTaxRate, goodsAndServicesTaxRate);
            decimal expectedPST = 0.04m;

            try
            {
                test.ProvincialSalesTaxRate = -9m;
                Assert.Fail("Did not throw ArgumentOutOfRangeException as expected.");
            }
            catch(ArgumentOutOfRangeException)
            {
                PrivateObject target = new PrivateObject(test, new PrivateType(typeof(Invoice)));
                decimal actualPST = (decimal)target.GetField("provincialSalesTaxRate");
                Assert.AreEqual(expectedPST, actualPST);
            }
        }

        [TestMethod]
        public void ProvincialSalesTaxRateProperty_StateNotUpdatedOnException_ValueGreaterThanOne_Test()
        {
            decimal provincialSalesTaxRate = 0.07m;
            decimal goodsAndServicesTaxRate = 0.2m;
            ServiceInvoice test = new ServiceInvoice(provincialSalesTaxRate, goodsAndServicesTaxRate);
            decimal expectedPST = 0.07m;

            try
            {
                test.ProvincialSalesTaxRate = 9m;
                Assert.Fail("Did not throw ArgumentOutOfRangeException as expected.");
            }
            catch (ArgumentOutOfRangeException)
            {
                PrivateObject target = new PrivateObject(test, new PrivateType(typeof(Invoice)));
                decimal actualPST = (decimal)target.GetField("provincialSalesTaxRate");
                Assert.AreEqual(expectedPST, actualPST);
            }
        }

        //GoodsAndServicesTaxRate property
        [TestMethod]
        public void GoodsAndServicesTaxRateProperty_GetAccessor_Test()
        {
            decimal provincialSalesTaxRate = 0.07m;
            decimal goodsAndServicesTaxRate = 0.02m;
            ServiceInvoice test = new ServiceInvoice(provincialSalesTaxRate, goodsAndServicesTaxRate);

            decimal expectedGST = 0.02m;
            decimal actualGST = test.GoodsAndServicesTaxRate;
            Assert.AreEqual(expectedGST, actualGST);
        }

        [TestMethod]
        public void GoodsAndServicesTaxRateProperty_SetAccessor_Test()
        {
            decimal provincialSalesTaxRate = 0.07m;
            decimal goodsAndServicesTaxRate = 0.2m;
            ServiceInvoice test = new ServiceInvoice(provincialSalesTaxRate, goodsAndServicesTaxRate);
            decimal expectedGST = 0.45m;
            test.GoodsAndServicesTaxRate = 0.45m;

            PrivateObject target = new PrivateObject(test, new PrivateType(typeof(Invoice)));
            decimal actualGST = (decimal)target.GetField("goodsAndServicesTaxRate");
            Assert.AreEqual(expectedGST, actualGST);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void GoodAndServicesTaxRateProperty_ValueCannotBeLessThanZero_Test()
        {
            decimal provincialSalesTaxRate = 0.07m;
            decimal goodsAndServicesTaxRate = 0.2m;
            ServiceInvoice test = new ServiceInvoice(provincialSalesTaxRate, goodsAndServicesTaxRate);
            test.GoodsAndServicesTaxRate = -9m;
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void GoodsAndServicesTaxRateProperty_ValueCannotBeGreaterThanOne_Test()
        {
            decimal provincialSalesTaxRate = 0.07m;
            decimal goodsAndServicesTaxRate = 0.2m;
            ServiceInvoice test = new ServiceInvoice(provincialSalesTaxRate, goodsAndServicesTaxRate);
            test.GoodsAndServicesTaxRate = 9m;
        }

        [TestMethod]
        public void GoodsAndServicesTaxRateProperty_StateNotUpdatedOnException_ValueLessThanZero_Test()
        {
            decimal provincialSalesTaxRate = 0.07m;
            decimal goodsAndServicesTaxRate = 0.01m;
            ServiceInvoice test = new ServiceInvoice(provincialSalesTaxRate, goodsAndServicesTaxRate);
            decimal expectedGST = 0.01m;

            try
            {
                test.GoodsAndServicesTaxRate = -8m;
                Assert.Fail("Did not throw ArgumentOutOfRangeException as expected.");
            }
            catch(ArgumentOutOfRangeException)
            {
                PrivateObject target = new PrivateObject(test, new PrivateType(typeof(Invoice)));
                decimal actualGST = (decimal)target.GetField("goodsAndServicesTaxRate");
                Assert.AreEqual(expectedGST, actualGST);
            }
        }

        [TestMethod]
        public void GoodsAndServicesTaxRateProperty_StateNotUpdatedOnException_ValueGreaterThanOne_Test()
        {
            decimal provincialSalesTaxRate = 0.07m;
            decimal goodsAndServicesTaxRate = 0.04m;
            ServiceInvoice test = new ServiceInvoice(provincialSalesTaxRate, goodsAndServicesTaxRate);
            decimal expectedGST = 0.04m;

            try
            {
                test.GoodsAndServicesTaxRate = 8m;
                Assert.Fail("Did not throw ArgumentOutOfRangeException as expected.");
            }
            catch (ArgumentOutOfRangeException)
            {
                PrivateObject target = new PrivateObject(test, new PrivateType(typeof(Invoice)));
                decimal actualGST = (decimal)target.GetField("goodsAndServicesTaxRate");
                Assert.AreEqual(expectedGST, actualGST);
            }
        }

        //AddCost property
        [TestMethod]
        public void AddCostProperty_AddForLabour_Test()
        {
            decimal provincialSalesTaxRate = 0.05m;
            decimal goodsAndServicesTaxRate = 0.07m;
            ServiceInvoice test = new ServiceInvoice(provincialSalesTaxRate, goodsAndServicesTaxRate);

            test.AddCost(CostType.Labour, 110.10m);
            decimal expectedLabourCost = 110.10m;
            decimal actualLabourCost = test.LabourCost;
            Assert.AreEqual(expectedLabourCost, actualLabourCost);
        }

        [TestMethod]
        public void AddCostProperty_AddForParts_Test()
        {
            decimal provincialSalesTaxRate = 0.05m;
            decimal goodsAndServicesTaxRate = 0.07m;
            ServiceInvoice test = new ServiceInvoice(provincialSalesTaxRate, goodsAndServicesTaxRate);

            test.AddCost(CostType.Part, 128.11m);
            decimal expectedPartsCost = 128.11m;
            decimal actualPartsCost = test.PartsCost;
            Assert.AreEqual(expectedPartsCost, actualPartsCost);
        }

        [TestMethod]
        public void AddCostProperty_AddForMaterials_Test()
        {
            decimal provincialSalesTaxRate = 0.05m;
            decimal goodsAndServicesTaxRate = 0.07m;
            ServiceInvoice test = new ServiceInvoice(provincialSalesTaxRate, goodsAndServicesTaxRate);

            test.AddCost(CostType.Material, 133.33m);
            decimal expectedMaterialCost = 133.33m;
            decimal actualMaterialCost = test.MaterialCost;
            Assert.AreEqual(expectedMaterialCost, actualMaterialCost);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void AddCost_AmountCannotbeLessThanZero_Test()
        {
            decimal provincialSalesTaxRate = 0.06m;
            decimal goodsAndServicesTaxRate = 1.05m;
            ServiceInvoice test = new ServiceInvoice(provincialSalesTaxRate, goodsAndServicesTaxRate);
            test.AddCost(CostType.Material, -10m);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void AddCost_AmountCannotbeZero_Test()
        {
            decimal provincialSalesTaxRate = 0.06m;
            decimal goodsAndServicesTaxRate = 1.05m;
            ServiceInvoice test = new ServiceInvoice(provincialSalesTaxRate, goodsAndServicesTaxRate);
            test.AddCost(CostType.Material, 0m);
        }

        [TestMethod]
        public void AddCostProperty_StateNotUpdatedOnException_ValueLessThanZero_Test()
        {
            decimal provincialSalesTaxRate = 0.10m;
            decimal goodsAndServicesTaxRate = 0.04m;
            ServiceInvoice test = new ServiceInvoice(provincialSalesTaxRate, goodsAndServicesTaxRate);
            decimal expectedMaterialCost = 8.96m;
            test.AddCost(CostType.Material, 8.96m);

            try
            {
                test.AddCost(CostType.Material, -5m);
                Assert.Fail("Did not throw ArgumentOutOfRangeException as expected.");
            }
            catch (ArgumentOutOfRangeException)
            {
                decimal actualMaterialCost = test.MaterialCost;
                Assert.AreEqual(expectedMaterialCost, actualMaterialCost);
            }
        }
        //ProvincialSalesTaxCharged property
        [TestMethod]
        public void ProvincialSalesTaxChargedProperty_Test()
        {
            decimal provincialSalesTaxRate = 0.10m;
            decimal goodsAndServicesTaxRate = 0.02m;
            ServiceInvoice test = new ServiceInvoice(provincialSalesTaxRate, goodsAndServicesTaxRate);

            test.AddCost(CostType.Material, 133.33m);
            test.AddCost(CostType.Part, 56.00m);
            test.AddCost(CostType.Labour, 77.98m);

            decimal expectedPSTCharged = 18.933m;
            decimal actualPSTCharged = test.ProvincialSalesTaxCharged;
            Assert.AreEqual(expectedPSTCharged, actualPSTCharged);
        }

        //GoodsAndServicesSalesTaxCharged property
        [TestMethod]
        public void GoodsAndServicesTaxChargedProperty_Test()
        {
            decimal provincialSalesTaxRate = 0.08m;
            decimal goodsAndServicesTaxRate = 0.06m;
            ServiceInvoice test = new ServiceInvoice(provincialSalesTaxRate, goodsAndServicesTaxRate);

            test.AddCost(CostType.Material, 133.33m);
            test.AddCost(CostType.Part, 56.00m);
            test.AddCost(CostType.Labour, 77.98m);

            decimal expectedGSTCharged = 16.0386m;
            decimal actualGSTCharged = test.GoodsAndServicesTaxCharged;
            Assert.AreEqual(expectedGSTCharged, actualGSTCharged);
        }

        //SubTotal property
        [TestMethod]
        public void SubTotalProperty_Test()
        {
            decimal provincialSalesTaxRate = 0.06m;
            decimal goodsAndServicesTaxRate = 0.08m;
            ServiceInvoice test = new ServiceInvoice(provincialSalesTaxRate, goodsAndServicesTaxRate);

            test.AddCost(CostType.Material, 40.73m);
            test.AddCost(CostType.Part, 7.09m);
            test.AddCost(CostType.Labour, 51.10m);

            decimal expectedSubtotal = 98.92m;
            decimal actualSubtotal = test.SubTotal;
            Assert.AreEqual(expectedSubtotal, actualSubtotal);
        }

        //Total property
        [TestMethod]
        public void TotalProperty_Test()
        {
            decimal provincialSalesTaxRate = 0.05m;
            decimal goodsAndServicesTaxRate = 0.07m;
            ServiceInvoice test = new ServiceInvoice(provincialSalesTaxRate, goodsAndServicesTaxRate);

            test.AddCost(CostType.Material, 40.73m);
            test.AddCost(CostType.Part, 7.09m);
            test.AddCost(CostType.Labour, 51.10m);

            decimal expectedTotal = 108.2354m;
            decimal actualTotal = test.Total;
            Assert.AreEqual(expectedTotal, actualTotal);
        }
    }
}
