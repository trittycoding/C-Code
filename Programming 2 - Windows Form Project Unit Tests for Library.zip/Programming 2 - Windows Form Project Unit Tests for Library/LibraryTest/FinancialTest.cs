﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Taylor.Travis.Business;

namespace LibraryTest
{
    [TestClass]
    public class FinancialTest
    {
        [TestMethod]
        public void GetPaymentMethod_Test()
        {
            decimal actualPayment = Math.Round(Financial.GetPayment(0.13m, 10, 1000m), 9);
            decimal expectedPayment = 184.289555828m;
            Assert.AreEqual(expectedPayment, actualPayment);

        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void GetPaymentMethod_RateIsLessThanZeroException_Test()
        {
            decimal rate = -1m;
            int numberOfPaymentPeriods = 10;
            decimal presentValue = 1000m;
            decimal actualPayment = Math.Round(Financial.GetPayment(rate, numberOfPaymentPeriods, presentValue));
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void GetPaymentMethod_RateIsGreaterThanOneException_Test()
        {
            decimal rate = 1.2m;
            int numberOfPaymentPeriods = 10;
            decimal presentValue = 1000m;
            decimal actualPayment = Math.Round(Financial.GetPayment(rate, numberOfPaymentPeriods, presentValue));
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void GetPaymentMethod_PaymentPeriodsLessThanZeroException_Test()
        {
            decimal rate = 0.13m;
            int numberOfPaymentPeriods = -10;
            decimal presentValue = 1000m;
            decimal actualPayment = Math.Round(Financial.GetPayment(rate, numberOfPaymentPeriods, presentValue));
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void GetPaymentMethod_PaymentPeriodsIsZeroException_Test()
        {
            decimal rate = 0.13m;
            int numberOfPaymentPeriods = 0;
            decimal presentValue = 1000m;
            decimal actualPayment = Math.Round(Financial.GetPayment(rate, numberOfPaymentPeriods, presentValue));
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void GetPaymentMethod_PresentValueIsLessThanZeroException_Test()
        {
            decimal rate = 0.13m;
            int numberOfPaymentPeriods = 10;
            decimal presentValue = -1000m;
            decimal actualPayment = Math.Round(Financial.GetPayment(rate, numberOfPaymentPeriods, presentValue));
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void GetPaymentMethod_PresentValueIsZeroException_Test()
        {
            decimal rate = 0.13m;
            int numberOfPaymentPeriods = 10;
            decimal presentValue = 0m;
            decimal actualPayment = Math.Round(Financial.GetPayment(rate, numberOfPaymentPeriods, presentValue));
        }
    }
}
