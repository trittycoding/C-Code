﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Taylor.Travis.Business;

namespace LibraryTest
{
    [TestClass]
    public class SalesQuoteTest
    {
        //Constructors
        [TestMethod]
        public void Constructor_5Param_Valid_Test()
        {
            //Arrange 
            decimal vehicleSalePrice = 12000m;
            decimal tradeInAmount = 1450m;
            decimal salesTaxRate = 0.13m;
            Accessories accessoriesChosen = Accessories.StereoAndLeather;
            ExteriorFinish exteriorFinishChosen = ExteriorFinish.Pearlized;
            SalesQuote test = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate, accessoriesChosen, exteriorFinishChosen);

            //Act - expected values (names of expected are abbreviated due to length)
            decimal expectedVSP = 12000m;
            decimal expectedTIA = 1450m;
            decimal expectedSTR = 0.13m;
            Accessories expectedAC = Accessories.StereoAndLeather;
            ExteriorFinish expectedEFC = ExteriorFinish.Pearlized;
            PrivateObject target = new PrivateObject(test);

            decimal actualVSP = (decimal)target.GetField("vehicleSalePrice");
            decimal actualTIA = (decimal)target.GetField("tradeInAmount");
            decimal actualSTR = (decimal)target.GetField("salesTaxRate");
            Accessories actualAC = (Accessories)target.GetField("accessoriesChosen");
            ExteriorFinish actualEFC = (ExteriorFinish)target.GetField("exteriorFinishChosen");

            //Assert
            Assert.AreEqual(expectedVSP, actualVSP);
            Assert.AreEqual(expectedTIA, actualTIA);
            Assert.AreEqual(expectedSTR, actualSTR);
            Assert.AreEqual(expectedAC, actualAC);
            Assert.AreEqual(expectedEFC, actualEFC);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void Constructor5Param_VSPCannotBeZero_Test()
        {
            decimal vehicleSalePrice = 0m;
            decimal tradeInAmount = 1000m;
            decimal salesTaxRate = 0.13m;
            Accessories accessoriesChosen = Accessories.StereoAndLeather;
            ExteriorFinish exteriorFinishChosen = ExteriorFinish.Pearlized;
            SalesQuote test = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate, accessoriesChosen, exteriorFinishChosen);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void Constructor5Param_VSPCannotBeLessThanZero_Test()
        {
            decimal vehicleSalePrice = -2m;
            decimal tradeInAmount = 1000m;
            decimal salesTaxRate = 0.13m;
            Accessories accessoriesChosen = Accessories.StereoAndLeather;
            ExteriorFinish exteriorFinishChosen = ExteriorFinish.Pearlized;
            SalesQuote test = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate, accessoriesChosen, exteriorFinishChosen);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void Constructor5Param_TIACannotBeLessThanZero_Test()
        {
            decimal vehicleSalePrice = 5000m;
            decimal tradeInAmount = -10m;
            decimal salesTaxRate = 0.13m;
            Accessories accessoriesChosen = Accessories.StereoAndLeather;
            ExteriorFinish exteriorFinishChosen = ExteriorFinish.Pearlized;
            SalesQuote test = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate, accessoriesChosen, exteriorFinishChosen);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void Constructor5Param_STRCannotBeLessThanZero_Test()
        {
            decimal vehicleSalePrice = 12000m;
            decimal tradeInAmount = 1000m;
            decimal salesTaxRate = -0.34m;
            Accessories accessoriesChosen = Accessories.StereoAndLeather;
            ExteriorFinish exteriorFinishChosen = ExteriorFinish.Pearlized;
            SalesQuote test = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate, accessoriesChosen, exteriorFinishChosen);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void Constructor5Param_STRCannotBeGreaterThanOne_Test()
        {
            decimal vehicleSalePrice = 34000m;
            decimal tradeInAmount = 1000m;
            decimal salesTaxRate = 3m;
            Accessories accessoriesChosen = Accessories.StereoAndLeather;
            ExteriorFinish exteriorFinishChosen = ExteriorFinish.Pearlized;
            SalesQuote test = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate, accessoriesChosen, exteriorFinishChosen);
        }

        [TestMethod]
        public void Constructor_3Param_Valid_Test()
        {
            //Arrange 
            decimal vehicleSalePrice = 10000m;
            decimal tradeInAmount = 1250m;
            decimal salesTaxRate = 0.15m;

            SalesQuote test = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate);

            //Act - expected values (names of expected are abbreviated due to length)
            decimal expectedVSP = 10000m;
            decimal expectedTIA = 1250m;
            decimal expectedSTR = 0.15m;
            Accessories expectedAC = Accessories.None;
            ExteriorFinish expectedEFC = ExteriorFinish.None;
            PrivateObject target = new PrivateObject(test);

            decimal actualVSP = (decimal)target.GetField("vehicleSalePrice");
            decimal actualTIA = (decimal)target.GetField("tradeInAmount");
            decimal actualSTR = (decimal)target.GetField("salesTaxRate");
            Accessories actualAC = (Accessories)target.GetField("accessoriesChosen");
            ExteriorFinish actualEFC = (ExteriorFinish)target.GetField("exteriorFinishChosen");

            //Assert
            Assert.AreEqual(expectedVSP, actualVSP);
            Assert.AreEqual(expectedTIA, actualTIA);
            Assert.AreEqual(expectedSTR, actualSTR);
            Assert.AreEqual(expectedAC, actualAC);
            Assert.AreEqual(expectedEFC, actualEFC);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void Constructor3Param_VSPCannotBeZero_Test()
        {
            decimal vehicleSalePrice = 0m;
            decimal tradeInAmount = 1000m;
            decimal salesTaxRate = 0.13m;
            SalesQuote test = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void Constructor3Param_VSPCannotBeLessThanZero_Test()
        {
            decimal vehicleSalePrice = -2m;
            decimal tradeInAmount = 1000m;
            decimal salesTaxRate = 0.13m;
            SalesQuote test = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void Constructor3Param_TIACannotBeLessThanZero_Test()
        {
            decimal vehicleSalePrice = 5000m;
            decimal tradeInAmount = -10m;
            decimal salesTaxRate = 0.13m;
            SalesQuote test = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void Constructor3Param_STRCannotBeLessThanZero_Test()
        {
            decimal vehicleSalePrice = 12000m;
            decimal tradeInAmount = 1000m;
            decimal salesTaxRate = -0.34m;
            SalesQuote test = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void Constructor3Param_STRCannotBeGreaterThanOne_Test()
        {
            decimal vehicleSalePrice = 34000m;
            decimal tradeInAmount = 1000m;
            decimal salesTaxRate = 3m;
            SalesQuote test = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate);
        }

        //VehicleSalePrice property
        [TestMethod]
        public void VehicleSalePriceProperty_GetAccessor()
        {
            decimal vehicleSalePrice = 38000m;
            decimal tradeInAmount = 1060m;
            decimal salesTaxRate = 0.13m;
            SalesQuote test = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate);

            decimal expectedVSP = 38000m;
            decimal actualVSP = test.VehicleSalePrice;

            Assert.AreEqual(expectedVSP, actualVSP);
        }

        [TestMethod]
        public void VehicleSalePriceProperty_SetAccessor()
        {
            decimal vehicleSalePrice = 38000m;
            decimal tradeInAmount = 1060m;
            decimal salesTaxRate = 0.13m;
            SalesQuote test = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate);

            decimal expectedVSP = 25000m;
            test.VehicleSalePrice = 25000m;

            PrivateObject target = new PrivateObject(test);
            decimal actualVSP = (decimal)target.GetField("vehicleSalePrice");
            Assert.AreEqual(expectedVSP, actualVSP);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void VehicleSalePriceProperty_ValueCannotBeZero()
        {
            decimal vehicleSalePrice = 33000m;
            decimal tradeInAmount = 1100m;
            decimal salesTaxRate = 0.12m;
            SalesQuote test = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate);
            test.VehicleSalePrice = 0;
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void VehicleSalePriceProperty_ValueCannotBeLessThanZero()
        {
            decimal vehicleSalePrice = 33000m;
            decimal tradeInAmount = 1100m;
            decimal salesTaxRate = 0.12m;
            SalesQuote test = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate);
            test.VehicleSalePrice = -2m;
        }

        [TestMethod]
        public void VehicleSalePriceProperty_StateNotUpdatedOnException_ValueOfZero_Test()
        {
            decimal vehicleSalePrice = 33000m;
            decimal tradeInAmount = 1100m;
            decimal salesTaxRate = 0.12m;
            SalesQuote test = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate);
            decimal expectedVSP = 33000m;
            try
            {
                test.VehicleSalePrice = 0;
                Assert.Fail("Did not throw ArgumentOutOfRangeException as expected.");
            }
            catch(ArgumentOutOfRangeException)
            {
                PrivateObject target = new PrivateObject(test);
                decimal actualVSP = (decimal)target.GetField("vehicleSalePrice");
                Assert.AreEqual(expectedVSP, actualVSP);
            }
        }

        [TestMethod]
        public void VehicleSalePriceProperty_StateNotUpdatedOnException_ValueOfLessThanZero_Test()
        {
            decimal vehicleSalePrice = 31000m;
            decimal tradeInAmount = 1100m;
            decimal salesTaxRate = 0.12m;
            SalesQuote test = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate);
            decimal expectedVSP = 31000m;
            try
            {
                test.VehicleSalePrice = -2;
                Assert.Fail("Did not throw ArgumentOutOfRangeException as expected.");
            }
            catch (ArgumentOutOfRangeException)
            {
                PrivateObject target = new PrivateObject(test);
                decimal actualVSP = (decimal)target.GetField("vehicleSalePrice");
                Assert.AreEqual(expectedVSP, actualVSP);
            }
        }

        //TradeInAmount property
        [TestMethod]
        public void TradeInAmountProperty_GetAccessor()
        {
            decimal vehicleSalePrice = 37000m;
            decimal tradeInAmount = 11000m;
            decimal salesTaxRate = 0.13m;
            SalesQuote test = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate);

            decimal expectedTIA = 11000m;
            decimal actualTIA = test.TradeInAmount;

            Assert.AreEqual(expectedTIA, actualTIA);
        }

        [TestMethod]
        public void TradeInAmountProperty_SetAccessor()
        {
            decimal vehicleSalePrice = 37000m;
            decimal tradeInAmount = 11000m;
            decimal salesTaxRate = 0.13m;
            SalesQuote test = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate);

            decimal expectedTIA = 8000m;
            test.TradeInAmount = 8000m;
            PrivateObject target = new PrivateObject(test);
            decimal actualTIA = (decimal)target.GetField("tradeInAmount");

            Assert.AreEqual(expectedTIA, actualTIA);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void TradeInAmountProperty_ValueCannotBeLessThanZero()
        {
            decimal vehicleSalePrice = 37000m;
            decimal tradeInAmount = 11000m;
            decimal salesTaxRate = 0.13m;
            SalesQuote test = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate);
            test.TradeInAmount = -2m;
        }

        [TestMethod]
        public void TradeInAmountProperty_StateNotUpdatedOnException_ValueOfLessThanZero_Test()
        {
            decimal vehicleSalePrice = 33000m;
            decimal tradeInAmount = 1100m;
            decimal salesTaxRate = 0.12m;
            SalesQuote test = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate);
            decimal expectedTIA = 1100m;
            try
            {
                test.TradeInAmount = -5;
                Assert.Fail("Did not throw ArgumentOutOfRangeException as expected.");
            }
            catch (ArgumentOutOfRangeException)
            {
                PrivateObject target = new PrivateObject(test);
                decimal actualTIA = (decimal)target.GetField("tradeInAmount");
                Assert.AreEqual(expectedTIA, actualTIA);
            }
        }

        //AccessoriesChosen property
        [TestMethod]
        public void AccessoriesChosenProperty_GetAccessor_OutComeNone()
        {
            decimal vehicleSalePrice = 37000m;
            decimal tradeInAmount = 11000m;
            decimal salesTaxRate = 0.13m;
            Accessories accessoriesChosen = Accessories.None;
            ExteriorFinish exteriorFinishChosen = ExteriorFinish.None;
            SalesQuote test = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate, accessoriesChosen, exteriorFinishChosen);

            Accessories expectedAC = Accessories.None;
            Accessories actualAC = test.AccessoriesChosen;
            Assert.AreEqual(expectedAC, actualAC);
        }

        [TestMethod]
        public void AccessoriesChosenProperty_GetAccessor_OutComeStereo()
        {
            decimal vehicleSalePrice = 37000m;
            decimal tradeInAmount = 11000m;
            decimal salesTaxRate = 0.13m;
            Accessories accessoriesChosen = Accessories.StereoSystem;
            ExteriorFinish exteriorFinishChosen = ExteriorFinish.None;
            SalesQuote test = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate, accessoriesChosen, exteriorFinishChosen);

            Accessories expectedAC = Accessories.StereoSystem;
            Accessories actualAC = test.AccessoriesChosen;
            Assert.AreEqual(expectedAC, actualAC);
        }

        [TestMethod]
        public void AccessoriesChosenProperty_GetAccessor_OutComeLeather()
        {
            decimal vehicleSalePrice = 37000m;
            decimal tradeInAmount = 11000m;
            decimal salesTaxRate = 0.13m;
            Accessories accessoriesChosen = Accessories.LeatherInterior;
            ExteriorFinish exteriorFinishChosen = ExteriorFinish.None;
            SalesQuote test = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate, accessoriesChosen, exteriorFinishChosen);

            Accessories expectedAC = Accessories.LeatherInterior;
            Accessories actualAC = test.AccessoriesChosen;
            Assert.AreEqual(expectedAC, actualAC);
        }

        [TestMethod]
        public void AccessoriesChosenProperty_GetAccessor_OutComeComputerNav()
        {
            decimal vehicleSalePrice = 37000m;
            decimal tradeInAmount = 11000m;
            decimal salesTaxRate = 0.13m;
            Accessories accessoriesChosen = Accessories.ComputerNavigation;
            ExteriorFinish exteriorFinishChosen = ExteriorFinish.None;
            SalesQuote test = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate, accessoriesChosen, exteriorFinishChosen);

            Accessories expectedAC = Accessories.ComputerNavigation;
            Accessories actualAC = test.AccessoriesChosen;
            Assert.AreEqual(expectedAC, actualAC);
        }

        [TestMethod]
        public void AccessoriesChosenProperty_GetAccessor_OutComeStereoAndLeather()
        {
            decimal vehicleSalePrice = 37000m;
            decimal tradeInAmount = 11000m;
            decimal salesTaxRate = 0.13m;
            Accessories accessoriesChosen = Accessories.StereoAndLeather;
            ExteriorFinish exteriorFinishChosen = ExteriorFinish.None;
            SalesQuote test = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate, accessoriesChosen, exteriorFinishChosen);

            Accessories expectedAC = Accessories.StereoAndLeather;
            Accessories actualAC = test.AccessoriesChosen;
            Assert.AreEqual(expectedAC, actualAC);
        }

        [TestMethod]
        public void AccessoriesChosenProperty_GetAccessor_OutComeStereoAndComputerNav()
        {
            decimal vehicleSalePrice = 37000m;
            decimal tradeInAmount = 11000m;
            decimal salesTaxRate = 0.13m;
            Accessories accessoriesChosen = Accessories.StereoAndNavigation;
            ExteriorFinish exteriorFinishChosen = ExteriorFinish.None;
            SalesQuote test = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate, accessoriesChosen, exteriorFinishChosen);

            Accessories expectedAC = Accessories.StereoAndNavigation;
            Accessories actualAC = test.AccessoriesChosen;
            Assert.AreEqual(expectedAC, actualAC);
        }

        [TestMethod]
        public void AccessoriesChosenProperty_GetAccessor_OutComeLeatherAndComputerNav()
        {
            decimal vehicleSalePrice = 37000m;
            decimal tradeInAmount = 11000m;
            decimal salesTaxRate = 0.13m;
            Accessories accessoriesChosen = Accessories.LeatherAndNavigation;
            ExteriorFinish exteriorFinishChosen = ExteriorFinish.None;
            SalesQuote test = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate, accessoriesChosen, exteriorFinishChosen);

            Accessories expectedAC = Accessories.LeatherAndNavigation;
            Accessories actualAC = test.AccessoriesChosen;
            Assert.AreEqual(expectedAC, actualAC);
        }

        [TestMethod]
        public void AccessoriesChosenProperty_GetAccessor_OutComeAll()
        {
            decimal vehicleSalePrice = 37000m;
            decimal tradeInAmount = 11000m;
            decimal salesTaxRate = 0.13m;
            Accessories accessoriesChosen = Accessories.All;
            ExteriorFinish exteriorFinishChosen = ExteriorFinish.None;
            SalesQuote test = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate, accessoriesChosen, exteriorFinishChosen);

            Accessories expectedAC = Accessories.All;
            Accessories actualAC = test.AccessoriesChosen;
            Assert.AreEqual(expectedAC, actualAC);
        }

        [TestMethod]
        public void AccessoriesChosenProperty_SetAccessor()
        {
            decimal vehicleSalePrice = 37000m;
            decimal tradeInAmount = 9000m;
            decimal salesTaxRate = 0.16m;
            Accessories accessoriesChosen = Accessories.All;
            ExteriorFinish exteriorFinishChosen = ExteriorFinish.None;
            SalesQuote test = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate, accessoriesChosen, exteriorFinishChosen);

            Accessories expectedAC = Accessories.StereoSystem;
            test.AccessoriesChosen = Accessories.StereoSystem;
            PrivateObject target = new PrivateObject(test);
            Accessories actualAC = (Accessories)target.GetField("accessoriesChosen");

            Assert.AreEqual(expectedAC, actualAC);
        }

        //AccessoryCost property
        [TestMethod]
        public void AccessoryCostProperty_NoneChosen_Test()
        {
            decimal vehicleSalePrice = 37000m;
            decimal tradeInAmount = 9000m;
            decimal salesTaxRate = 0.16m;
            Accessories accessoriesChosen = Accessories.None;
            ExteriorFinish exteriorFinishChosen = ExteriorFinish.None;
            SalesQuote test = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate, accessoriesChosen, exteriorFinishChosen);

            decimal expectedAccessoryCost = 0;
            decimal actualAccessoryCost = test.AccessoryCost;
            Assert.AreEqual(expectedAccessoryCost, actualAccessoryCost);
        }

        [TestMethod]
        public void AccessoryCostProperty_StereoChosen_Test()
        {
            decimal vehicleSalePrice = 37000m;
            decimal tradeInAmount = 9000m;
            decimal salesTaxRate = 0.16m;
            Accessories accessoriesChosen = Accessories.StereoSystem;
            ExteriorFinish exteriorFinishChosen = ExteriorFinish.None;
            SalesQuote test = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate, accessoriesChosen, exteriorFinishChosen);

            decimal expectedAccessoryCost = 505.05m;
            decimal actualAccessoryCost = test.AccessoryCost;
            Assert.AreEqual(expectedAccessoryCost, actualAccessoryCost);
        }

        [TestMethod]
        public void AccessoryCostProperty_LeatherChosen_Test()
        {
            decimal vehicleSalePrice = 37000m;
            decimal tradeInAmount = 9000m;
            decimal salesTaxRate = 0.16m;
            Accessories accessoriesChosen = Accessories.LeatherInterior;
            ExteriorFinish exteriorFinishChosen = ExteriorFinish.None;
            SalesQuote test = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate, accessoriesChosen, exteriorFinishChosen);

            decimal expectedAccessoryCost = 1010.10m;
            decimal actualAccessoryCost = test.AccessoryCost;
            Assert.AreEqual(expectedAccessoryCost, actualAccessoryCost);
        }

        [TestMethod]
        public void AccessoryCostProperty_NavChosen_Test()
        {
            decimal vehicleSalePrice = 37000m;
            decimal tradeInAmount = 9000m;
            decimal salesTaxRate = 0.16m;
            Accessories accessoriesChosen = Accessories.ComputerNavigation;
            ExteriorFinish exteriorFinishChosen = ExteriorFinish.None;
            SalesQuote test = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate, accessoriesChosen, exteriorFinishChosen);

            decimal expectedAccessoryCost = 1515.15m;
            decimal actualAccessoryCost = test.AccessoryCost;
            Assert.AreEqual(expectedAccessoryCost, actualAccessoryCost);
        }

        [TestMethod]
        public void AccessoryCostProperty_StereoAndLeatherChosen_Test()
        {
            decimal vehicleSalePrice = 37000m;
            decimal tradeInAmount = 9000m;
            decimal salesTaxRate = 0.16m;
            Accessories accessoriesChosen = Accessories.StereoAndLeather;
            ExteriorFinish exteriorFinishChosen = ExteriorFinish.None;
            SalesQuote test = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate, accessoriesChosen, exteriorFinishChosen);

            decimal expectedAccessoryCost = 1515.15m;
            decimal actualAccessoryCost = test.AccessoryCost;
            Assert.AreEqual(expectedAccessoryCost, actualAccessoryCost);
        }

        [TestMethod]
        public void AccessoryCostProperty_StereoAndNavChosen_Test()
        {
            decimal vehicleSalePrice = 37000m;
            decimal tradeInAmount = 9000m;
            decimal salesTaxRate = 0.16m;
            Accessories accessoriesChosen = Accessories.StereoAndNavigation;
            ExteriorFinish exteriorFinishChosen = ExteriorFinish.None;
            SalesQuote test = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate, accessoriesChosen, exteriorFinishChosen);

            decimal expectedAccessoryCost = 2020.20m;
            decimal actualAccessoryCost = test.AccessoryCost;
            Assert.AreEqual(expectedAccessoryCost, actualAccessoryCost);
        }

        [TestMethod]
        public void AccessoryCostProperty_LeatherAndNavChosen_Test()
        {
            decimal vehicleSalePrice = 37000m;
            decimal tradeInAmount = 9000m;
            decimal salesTaxRate = 0.16m;
            Accessories accessoriesChosen = Accessories.LeatherAndNavigation;
            ExteriorFinish exteriorFinishChosen = ExteriorFinish.None;
            SalesQuote test = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate, accessoriesChosen, exteriorFinishChosen);

            decimal expectedAccessoryCost = 2525.25m;
            decimal actualAccessoryCost = test.AccessoryCost;
            Assert.AreEqual(expectedAccessoryCost, actualAccessoryCost);
        }

        [TestMethod]
        public void AccessoryCostProperty_AllChosen_Test()
        {
            decimal vehicleSalePrice = 37000m;
            decimal tradeInAmount = 9000m;
            decimal salesTaxRate = 0.16m;
            Accessories accessoriesChosen = Accessories.All;
            ExteriorFinish exteriorFinishChosen = ExteriorFinish.None;
            SalesQuote test = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate, accessoriesChosen, exteriorFinishChosen);

            decimal expectedAccessoryCost = 3030.30m;
            decimal actualAccessoryCost = test.AccessoryCost;
            Assert.AreEqual(expectedAccessoryCost, actualAccessoryCost);
        }

        //FinishCost property
        [TestMethod]
        public void FinishCostProperty_NoneChosen_Test()
        {
            decimal vehicleSalePrice = 37000m;
            decimal tradeInAmount = 9000m;
            decimal salesTaxRate = 0.16m;
            Accessories accessoriesChosen = Accessories.All;
            ExteriorFinish exteriorFinishChosen = ExteriorFinish.None;
            SalesQuote test = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate, accessoriesChosen, exteriorFinishChosen);

            decimal expectedFinishCost = 0;
            decimal actualFinishCost = test.FinishCost;
            Assert.AreEqual(expectedFinishCost, actualFinishCost);
        }

        [TestMethod]
        public void FinishCostProperty_StandardChosen_Test()
        {
            decimal vehicleSalePrice = 37000m;
            decimal tradeInAmount = 9000m;
            decimal salesTaxRate = 0.16m;
            Accessories accessoriesChosen = Accessories.None;
            ExteriorFinish exteriorFinishChosen = ExteriorFinish.Standard;
            SalesQuote test = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate, accessoriesChosen, exteriorFinishChosen);

            decimal expectedFinishCost = 202.02m;
            decimal actualFinishCost = test.FinishCost;
            Assert.AreEqual(expectedFinishCost, actualFinishCost);
        }

        [TestMethod]
        public void FinishCostProperty_PearlizedChosen_Test()
        {
            decimal vehicleSalePrice = 37000m;
            decimal tradeInAmount = 9000m;
            decimal salesTaxRate = 0.16m;
            Accessories accessoriesChosen = Accessories.All;
            ExteriorFinish exteriorFinishChosen = ExteriorFinish.Pearlized;
            SalesQuote test = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate, accessoriesChosen, exteriorFinishChosen);

            decimal expectedFinishCost = 404.04m;
            decimal actualFinishCost = test.FinishCost;
            Assert.AreEqual(expectedFinishCost, actualFinishCost);
        }

        [TestMethod]
        public void FinishCostProperty_CustomChosen_Test()
        {
            decimal vehicleSalePrice = 37000m;
            decimal tradeInAmount = 9000m;
            decimal salesTaxRate = 0.16m;
            Accessories accessoriesChosen = Accessories.All;
            ExteriorFinish exteriorFinishChosen = ExteriorFinish.Custom;
            SalesQuote test = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate, accessoriesChosen, exteriorFinishChosen);

            decimal expectedFinishCost = 606.06m;
            decimal actualFinishCost = test.FinishCost;
            Assert.AreEqual(expectedFinishCost, actualFinishCost);
        }

        //Subtotal property
        [TestMethod]
        public void SubTotalProperty_Test()
        {
            decimal vehicleSalePrice = 19000m;
            decimal tradeInAmount = 9050m;
            decimal salesTaxRate = 0.10m;
            Accessories accessoriesChosen = Accessories.StereoAndLeather;
            ExteriorFinish exteriorFinishChosen = ExteriorFinish.Pearlized;
            SalesQuote test = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate, accessoriesChosen, exteriorFinishChosen);

            decimal expectedSubtotal = 20919.19m;
            decimal actualSubtotal = test.Subtotal;
            Assert.AreEqual(expectedSubtotal, actualSubtotal);
        }

        //SalesTax property
        [TestMethod]
        public void SalesTaxProperty_Test()
        {
            decimal vehicleSalePrice = 20000m;
            decimal tradeInAmount = 7000m;
            decimal salesTaxRate = 0.12m;
            Accessories accessoriesChosen = Accessories.StereoSystem;
            ExteriorFinish exteriorFinishChosen = ExteriorFinish.None;
            SalesQuote test = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate, accessoriesChosen, exteriorFinishChosen);

            decimal expectedSalesTax = 2460.606m;
            decimal actualSalesTax = test.SalesTax;
            Assert.AreEqual(expectedSalesTax, actualSalesTax);
        }

        //Total property
        [TestMethod]
        public void TotalProperty_Test()
        {
            decimal vehicleSalePrice = 20000m;
            decimal tradeInAmount = 7000m;
            decimal salesTaxRate = 0.12m;
            Accessories accessoriesChosen = Accessories.StereoSystem;
            ExteriorFinish exteriorFinishChosen = ExteriorFinish.None;
            SalesQuote test = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate, accessoriesChosen, exteriorFinishChosen);

            decimal expectedTotal = 22965.656m;
            decimal actualTotal = test.Total;
            Assert.AreEqual(expectedTotal, actualTotal);
        }


        //AmountDue property
        [TestMethod]
        public void AmountDueProperty_Test()
        {
            decimal vehicleSalePrice = 20000m;
            decimal tradeInAmount = 7000m;
            decimal salesTaxRate = 0.12m;
            Accessories accessoriesChosen = Accessories.StereoSystem;
            ExteriorFinish exteriorFinishChosen = ExteriorFinish.None;
            SalesQuote test = new SalesQuote(vehicleSalePrice, tradeInAmount, salesTaxRate, accessoriesChosen, exteriorFinishChosen);

            decimal expectedAmountDue = 15965.656m;
            decimal actualAmountDue = test.AmountDue;
            Assert.AreEqual(expectedAmountDue, actualAmountDue);
        }
    }
}
